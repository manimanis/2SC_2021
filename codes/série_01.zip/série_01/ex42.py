# Ex 42
x = int(input("Donner x ? "))

if x % 2 == 0:
    print(x, "est pair")
else:
    print(x, "est impair")
