# Ex 43
age = int(input("Donner votre age ? "))

if age >= 18:
    print("Vous avez", age, "ans. Vous êtes majeur.")
else:
    print("Vous avez", age, "ans. Vous êtes mineur.")
