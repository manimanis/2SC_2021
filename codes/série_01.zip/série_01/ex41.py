# Ex 41
x = int(input("Donner x ? "))
y = int(input("Donner y ? "))

if x > y:
    print("Le maximum entre", x, "et", y, "est", x)
else:
    print("Le maximum entre", x, "et", y, "est", y)
